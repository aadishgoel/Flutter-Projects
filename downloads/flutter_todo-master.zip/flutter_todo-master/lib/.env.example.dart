class Configure {
  static const String AppName = 'Flutter Todo';
  static const String FirebaseUrl = '[YOUR FIREBASE URL]';
  static const String ApiKey = '[YOUR API KEY]';
}
