import 'package:flutter/material.dart';

class Task{
  final Color color;
  final String title;
  final int date;
  
  Task(this.color, this.title, this.date);
  
}